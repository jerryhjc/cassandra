//@ sourceURL=logs/_scenario.scenario_20200724_064819_426.js

scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss-5050.yaml',
    'tags':     'phase:main',
    'host':     '10.128.15.211,10.128.15.212,10.128.15.213',
    'username': 'cassandra',
    'password': 'cassandra',
    'cycles':   '1M..10M',
    'threads':  'auto',
    'pooling':  '2:4:50',
    'async':    '10'
});
