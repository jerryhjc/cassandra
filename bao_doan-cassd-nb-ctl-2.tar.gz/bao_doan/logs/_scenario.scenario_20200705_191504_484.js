//@ sourceURL=logs/_scenario.scenario_20200705_191504_484.js

scenario.run({
    'type': 'cql',
    'yaml': './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss.yaml',
    'tags': 'phase:main',
    'host': '10.12'
});
