//@ sourceURL=logs/_scenario.scenario_20200723_223339_274.js

scenario.run({
    'type': 'cql',
    'yaml': './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss.ya'
});
