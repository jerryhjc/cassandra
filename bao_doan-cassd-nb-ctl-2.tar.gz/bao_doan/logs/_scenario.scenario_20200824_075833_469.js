//@ sourceURL=logs/_scenario.scenario_20200824_075833_469.js

scenario.run({
    'type': 'cql',
    'yaml': './nosqlbench/driver-cql-shaded/src/main/resources/activities/b'
});
