scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss-5050.yaml',
    'tags':     'phase:main',
    'host':     '10.128.15.211,10.128.15.212,10.128.15.213,10.128.15.214,10.128.15.215,10.128.15.216',
    'username': 'cassandra',
    'password': 'cassandra',
    'cycles':   '1M..30M',
    'threads':  '720',
    'pooling':  '4:8:100',
    'async':    '7200'
});
