scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss-1090.yaml',
    'tags':     'phase:main',
    'host':     '10.128.15.211,10.128.15.212,10.128.15.213',
    'username': 'cassandra',
    'password': 'cassandra',
    'cycles':   '1M..30M',
    'threads':  '1000',
    'pooling':  '2:4:50',
    'async':    '10000'
});
