//@ sourceURL=logs/_scenario.scenario_20200727_221014_388.js

scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss.yaml',
    'tags':     'phase:rampup',
    'host':     '10.128.15.211',
    'username': 'cassandra',
    'password': 'cassandra',
    'cycles':   '10M..100M',
    'threads':  'auto',
    'async':    '100'
});
