//@ sourceURL=logs/_scenario.scenario_20200704_082736_269.js

scenario.run({
    'type':    'cql',
    'yaml':    './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss.yaml',
    'tags':    'phase:main',
    'host':    '10.128.15.211',
    'cycles':  '10M..100M',
    'threads': 'auto',
    'pooling': '2:4:50',
    'async':   '7000'
});
