//@ sourceURL=logs/_scenario.scenario_20200703_082658_042.js

scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-dse.yaml',
    'tags':     'phase:main',
    'host':     '10.128.15.211',
    'username': 'cassandra',
    'password': 'cassandra',
    'cycles':   '500M..1000M',
    'threads':  'auto',
    'async':    '7000',
    'pooling':  '2:2:50'
});
