//@ sourceURL=logs/_scenario.scenario_20200812_144401_451.js

scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss.yaml',
    'tags':     'phase:rampup',
    'host':     '10.128.15.211',
    'username': 'cassandra',
    'password': 'cassandra',
    'cycles':   '1M..30M',
    'threads':  'auto',
    'async':    '100'
});
