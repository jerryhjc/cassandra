//@ sourceURL=logs/_scenario.scenario_20200724_075612_566.js

scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss.yaml',
    'tags':     'phase:schema',
    'host':     '10.128.15.211',
    'username': 'cassandra',
    'password': 'cassandra'
});
