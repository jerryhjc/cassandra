scenario.run({
    'type': 'cql',
    'yaml': './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss.ya'
});
