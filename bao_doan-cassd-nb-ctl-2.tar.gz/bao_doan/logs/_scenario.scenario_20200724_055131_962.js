//@ sourceURL=logs/_scenario.scenario_20200724_055131_962.js

scenario.run({
    'type': 'cql',
    'yaml': './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss-9010.yaml',
    'tags': 'phase'
});
