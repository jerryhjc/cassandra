//@ sourceURL=logs/_scenario.scenario_20200811_084228_441.js

scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss-9010.yaml',
    'tags':     'phase:main',
    'host':     '10.128.15.211,10.128.15.212,10.128.15.213,10.128.15.214,10.128.15.215,10.128.15.216',
    'username': 'cassandra',
    'password': 'cassandra',
    'cycles':   '1M..10M',
    'threads':  'auto',
    'pooling':  '2:8:50',
    'async':    '20'
});
