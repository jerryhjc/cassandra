scenario.run({
    'type':     'cql',
    'yaml':     './nosqlbench/driver-cql-shaded/src/main/resources/activities/baselines/cql-iot-oss.yaml',
    'tags':     'phase:rampup',
    'host':     '10.128.15.211,10.128.15.212,10.128.15.213,10.128.15.214,10.128.15.215,10.128.15.216',
    'username': 'cassandra',
    'password': 'cassandra',
    'cycles':   '1M..30M',
    'threads':  '640',
    'pooling':  '2:8:50',
    'async':    '6400'
});
